<!DOCTYPE html>
<html>
<head>
    <title>PHP Calculator</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .calculator {
            background: white;
            padding: 30px;
            width: 350px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            text-align: center;
        }

        input {
            width: 90%;
            padding: 12px;
            margin: 8px 0;
            font-size: 16px;
        }

        button {
            padding: 10px 15px;
            margin: 5px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            background: #007bff;
            color: white;
            font-size: 14px;
        }

        button:hover {
            background: #0056b3;
        }

        .clear {
            background: #6c757d;
        }

        .result {
            margin-top: 20px;
            font-size: 20px;
            font-weight: bold;
        }
    </style>
</head>

<body>

<div class="calculator">

    <h2>PHP Calculator</h2>

    <form method="POST">

        <input type="number" name="num1" placeholder="First number">
        <input type="number" name="num2" placeholder="Second number">

        <br>

        <button type="submit" name="operation" value="add">Add</button>
        <button type="submit" name="operation" value="subtract">Subtract</button>
        <button type="submit" name="operation" value="multiply">Multiply</button>
        <button type="submit" name="operation" value="divide">Divide</button>

        <button class="clear" type="reset">Clear</button>

    </form>

<?php

function addNumbers($a, $b) {
    return $a + $b;
}

function subtractNumbers($a, $b) {
    return $a - $b;
}

function multiplyNumbers($a, $b) {
    return $a * $b;
}

function divideNumbers($a, $b) {
    if($b == 0) {
        return "Cannot divide by zero";
    }

    return $a / $b;
}

if(isset($_POST['num1']) && isset($_POST['num2']) && isset($_POST['operation'])) {

    $num1 = $_POST['num1'];
    $num2 = $_POST['num2'];

    if($_POST['operation'] == "add") {
        $result = addNumbers($num1, $num2);
    } elseif($_POST['operation'] == "subtract") {
        $result = subtractNumbers($num1, $num2);
    } elseif($_POST['operation'] == "multiply") {
        $result = multiplyNumbers($num1, $num2);
    } elseif($_POST['operation'] == "divide") {
        $result = divideNumbers($num1, $num2);
    }

    echo "<div class='result'>Result: $result</div>";
}

?>

</div>

</body>
</html>